#' Compute the Covariance of a Matern process
#'
#' @param d scalar. Integer value to be chosen in \{1,3,5\}.The choice of \code{d}
#' affects the choice of the function \eqn{f}, as detailed in Description.
#'
#' @param hyp vector. Set of parameters for the Covariance definition. See
#' Details for further details.
#'
#' @param x vector. Vector containing the
#'  abscissa points where the Covariance is defined.
#'
#' @param z option. Can make the the matrix diagonal (if \code{z = "diag"}). Default
#' is \code{NULL}, for a non diagonal matrix.
#'
#' @param i scalar. Integer value to be chosen in \{1,2\} or \code{NULL} (as Default).
#' Controls the structure of the covariance matrix. 
#'
#' @return \code{d} \eqn{\times}\code{d} covariance matrix.
#'
#' @export covMaterniso
#'
#' @import flexclust
#'
#' @description  Matern covariance function with \eqn{\nu = \code{d}/2} and
#' isotropic distance measure. For
#' \code{d = 1} the function is also known as the exponential covariance function or the
#' Ornstein-Uhlenbeck covariance in 1d. 
#' 
#' @details The covariance function is:
#' \deqn{
#' k(x,y) = s^2  f( \sqrt{d} \cdot r )  exp(-\sqrt{d} \cdot r)
#' }
#' with
#' \itemize{
#' \item \eqn{f(t)=1} for \code{d=1}
#' \item \eqn{f(t)=1+t} for \code{d=3}
#' \item \eqn{f(t)=1+t+t^2/3} for \code{d=5}
#' }
#' Here \eqn{r} is the distance
#' \deqn{\sqrt{(x-y) P^{-1} (x-y),}} \eqn{P} is a \eqn{l} dependent parameter and
#'  \eqn{s^2} is the signal variance. The hyperparameters are:
#' \deqn{
#' hyp = [ \log(l), \log(\sqrt{s^2}) ]
#' }
#'
#'
#' See Carl Edward Rasmussen and Hannes Nickisch, 2010-09-10.
#' @examples
#' # Defintion of a Gaussian process
#' # with Matern Covariance
#'
#' # Time domain of the Gaussian Process
#' M <- 50
#' T_domain <- seq(0, 1, length = M)
#'
#' # paramteters of the Matern Covariance
#' nu_alpha <- 2.5
#' range <- 1/4
#' variance <- 1
#' hyp <- c(log(range), log(variance)/2)
#'
#' # mean of the process
#' mu_alpha <- rep(0,M)
#'
#' # covariance structure
#' Sig_alpha <- covMaterniso(2*nu_alpha, hyp, T_domain)
#'
#' # definition of the process
#'
#' # alpha <- mvrnorm(mu=mu_alpha, Sigma=Sig_alpha, n=1) # if MASS inslalled
#'

covMaterniso <- function(d, hyp, x, z=NULL, i=NULL)
{
    # Matern covariance function with nu = d/2 and isotropic distance measure. For
    # d=1 the function is also known as the exponential covariance function or the
    # Ornstein-Uhlenbeck covariance in 1d. The covariance function is:
    #
    #   k(x^p,x^q) = s2f * f( sqrt(d)*r ) * exp(-sqrt(d)*r)
    #
    # with f(t)=1 for d=1, f(t)=1+t for d=3 and f(t)=1+t+tÂ²/3 for d=5.
    # Here r is the distance sqrt((x^p-x^q)'*inv(P)*(x^p-x^q)), P is ell times
    # the unit matrix and sf2 is the signal variance. The hyperparameters are:
    #
    # hyp = [ log(ell)
    #         log(sqrt(sf2)) ]
    #
    # Copyright (c) by Carl Edward Rasmussen and Hannes Nickisch, 2010-09-10.

    if(!is.null(z))
    {
        is_diag <- z == 'diag'
        is_null_z <- FALSE
    }else{
        is_diag <- 0
        is_null_z <- TRUE
    }

    if ( !(d %in% c(1,3,5) ) )
    {
        stop("only 1, 3, 5 allowed for d")
    }

    ell <- exp(hyp[1])
    sf2 <- exp(2*hyp[2])

    if (d==1)
    {
        f <- function(t) {return (1)}
        df <- function(t) {return (1)}
    }

    if (d==3)
    {
        f <- function(t) {return (1+t)}
        df <- function(t) {return (t)}
    }

    if (d==5)
    {
        f <- function(t) { return (1 + t*(1+t/3)) }
        df <- function(t) { return (t*(1+t)/3) }
    }

    m <- function(t,f) {  return ( f(t)*exp(-t) ) }

    dm <- function(t,f,df) { return ( df(t) * t* exp(-t) ) }


    if (is_diag)
    {
        K <- rep(0, dim(x)[1]) # if is_diag==TRUE, x is a matrix => number of rows
    }else
    {
        if (is_null_z)
        {
            K <- sq_dist(sqrt(d) %*% t(x)/ell, sqrt(d) %*% t(x)/ell , squared=FALSE)
        }else{
            K <- sq_dist(sqrt(d) %*% t(x)/ell, sqrt(d) %*% t(z)/ell , squared=FALSE)
        }
    }

    if (is.null(i))
    {
        K <- sf2*m(K,f)
    }else{
        if (!(i %in% c(1,2)))
        {
            stop("only value 1 and 2 allowed for i")
        }else{
            if (i==1)
            {
                K=sf2*dm(K,f,df)
            }else{
                K=2*sf2*m(K,f)
            }
        }
    }
    return(K)
}

sq_dist <- function(dato_1, dato_2, squared=TRUE) # matrix containing in the columns the vectors
{
    if (squared==TRUE)
    {
        d <- dist2(t(dato_1), t(dato_2))^2
    }
    else{
        d <- dist2(t(dato_1), t(dato_2))
    }
    return(d)
}
