#' Definition of the kernel for the Sobolev Space \eqn{H^1}
#' 
#' @description Definition of the eigenfunctions and eigenvalues of the
#' kernel for the Sobolev Space \eqn{H^1}.
#'
#' @param a scalar. left end point of the domain.
#' @param b scalar. right end point of the domain.
#' @param m scalar, integer. number of points of the interval domain.
#' @param tau scalar. weight associated to the derivative in
#' \eqn{\| \cdot \|_\mathcal{K}}, the norm associated to the kernel. See Details
#' for the explicit definition of the norm.
#' @param plot.eigen bool. if \code{TRUE} the cumulative sum of the
#' eigenvalues of the kernel is plotted. Default is \code{FALSE}.
#'
#' @return list containing
#' \itemize{
#' \item \code{vectors} matrix. \code{m} \eqn{times} \code{m} matrix containing
#' the eigenvectors of the kernel. Each column contains the evaluation of an
#' eigenfunction on the domain \code{seq(a, b, length = m)}.
#' \item \code{values} vector. \code{m} length vector containing the eigenvalues
#' of the kernel
#' }
#'
#' @details The norm associated to the Sobolev kernel, dependent on the 
#' smoothing parameter \eqn{\sigma} is
#' \deqn{
#' \|f\|^2 = \|f\|^2_{L^2} + 1/\sigma \|f^{\prime}\|^2_{L^2}
#' }
#' This function is implicitly called in the \link[=generation_kernel]{generation_kernel}
#' function when \code{type} parameter is \code{'Sobolev'}. See the Vignette for
#' the explicit definition of the kernel.
#' @export
#'
#' @examples
#' sobolev_kernel(a = 0, b = 1, m = 100,
#'                tau = 1, plot.eigen = FALSE)
#'

sobolev_kernel <- function( a, b, m,
                           tau, plot.eigen = FALSE )
{

        K1<-function(t,s){
            if(t < s)
                return(tau * cosh(tau*(b-s))*cosh(tau*(t-a))/sinh(tau*(b-a)))
            else
                return(tau * cosh(tau*(b-t))*cosh(tau*(s-a))/sinh(tau*(b-a)))
        }

        pts<-seq(0,1,length=m)
        Sigma<-matrix(nrow=m,ncol=m)
        for(i in 1:m){
            for(j in i:m){
                Sigma[i,j] = K1(pts[i],pts[j])
                Sigma[j,i] = Sigma[i,j]
            }
        }

        E_Sig<-eigen(Sigma)
        VAL <- E_Sig$values
        if (plot.eigen)
            plot(cumsum(VAL)/sum(VAL))
        V<-E_Sig$vectors

        return(list(vectors = V, values = VAL )) # per each column an eigenvector.


}
